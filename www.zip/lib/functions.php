<?php
   //цей файл не одразу вирішив створити, спочатку все було розкидано
   //потім вирішив зробити як у WordPress - вивести всі важливі функ. в окремий файл
   $mysqli=false;
   function ConnectDB(){
	  global $mysqli;
	  $mysqli = new mysqli("localhost","root","","softgroup");
   }
   function closeDB(){
	   global $mysqli;
	   $mysqli->close();
   }
   function checkUser($login,$pass){
	  global $mysqli;
      connectDB();
	  $result_set = $mysqli->query("select * from `users` where `login`='$login' and `password`='$pass'");
	  closeDB();
	  if($result_set->fetch_assoc()) return true;
	  else return false;
   }
   function isAdmin($login){
	  global $mysqli;
      connectDB();
	  $result_set = $mysqli->query("select * from `users` where `login`='$login'");
	  closeDB();
	  $row = $result_set->fetch_assoc();
	  return $row["type"];
   }
   function articles_new($title,$sh_desc,$desc){
	   global $mysqli;
	   connectDB();
	   $title=trim($title);
	   $sh_desc=trim($sh_desc);
	   $desc=trim($desc);
	   if($title=="")
		   return false;
	   $result = $mysqli->query("INSERT INTO `data` (`title`,`m_desc`,`desc`,`category_id`) values('$title','$sh_desc','$desc',1)") or die($mysqli->error);
	   closeDB();
	   return true;
   }
   function article_edit($id,$title,$sh_desc,$desc){
	   //корегування статті, 
	   //але це не є обов'язковим завданням Софтгроуп
	   echo "Це не є обов'язковим завданням Софтгроуп";
   }
   function article_delete($id){
	   //вилучення статті, 
	   //але це не є обов'язковим завданням Софтгроуп
	   echo "Це не є обов'язковим завданням Софтгроуп";
   }
?>