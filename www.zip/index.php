<?php
  include("connect.php");
  session_start();
  require_once "lib/functions.php";
  
  $admin=0; 
?>
<!DOCTYPE html>
<html>
<head>
   <title>
   Тестове завдання SoftGroup
   </title>
   <meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
   <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
   <div class="wrapper">
   <div class="header">
   <img id="logo" src="/img/logo.jpg">
   </div>
   <div class="content">
      <div class="left">
	     <?php
			mysql_query("SET CHARACTER SET 'utf8'");
		    $result = mysql_query("select * from data order by id desc limit 0 , 10") or die(mysql_error());
		    $data = mysql_fetch_array($result);
			do{
				printf('
				    <div class="article">
					<img src="%s" width="100"/>
					<a href="#"><h3>%s</h3></a>
					<p>%s</p>
					<div style="clear:both;"></div>
					</div>',$data["img_url"],$data["title"],$data["m_desc"]);
			}
			while($data = mysql_fetch_array($result));
		 ?>
	  </div>
      <div class="right">
	  	<div class="right_menu">
	       <a href="/">Головна</a>
	       <a href="/register.php">Реєстрація</a>
		   <?php
		      if($admin==1){
				  printf('<a href="/admin.php">Реєстрація</a>');
			  }
		   ?>
	    </div>
	  </div>
	  <?php
	     if(isset($_POST['enter'])){
			 $e_login=$_POST['e_login'];
			 $e_password=md5($_POST['e_password']);
			if(checkUser($e_login,$e_password)){
				//echo "Succes";
				$_SESSION['login']=$e_login;
				$_SESSION['password']=$e_password;
				echo "<p>Привіт ";
				echo $_SESSION['login']."</p>";
				 if(isAdmin($e_login)){					 
					 printf('<a href="/admin/index.php">Адміністрування</a>');				 
				 }
				 else{				    
					echo "<p>Ви не адмін!</p>";
				 }
				 printf('<p><a href="logout.php">Вихід</a></p>');
			 }
			 else{
				 echo "Поимлка!";
				 printf('<form method="post" action="index.php">
                    <input type="text" name="e_login" placeholder=" | Логін" required /><br>
                    <input type="password" name="e_password" placeholder=" | Пароль" required /><br>
                    <input type="submit" name="enter" value="Увійти" />
                    </form>');
			 }
		 }
		 else{
			 if(checkUser($_SESSION['login'],$_SESSION['password'])){
				echo "<p>Привіт ";
				echo $_SESSION['login']."</p>";
				if(isAdmin($_SESSION['login'])){
					 //echo "Привіт адмін!<br />";
					 $admin=1;//
					 printf('<a href="/admin/index.php">Адміністрування</a>');					 
				 } 
				 
				 printf('<p><a href="logout.php">Вихід</a></p>');
			 }
			 else{
			printf('<form method="post" action="index.php">
               <input type="text" name="e_login" placeholder=" | Логін" required /><br>
               <input type="password" name="e_password" placeholder=" | Пароль" required /><br>
               <input type="submit" name="enter" value="Увійти" />
               </form>'); 
			 }
		 }
	  ?>
	  <div style="clear:both;"></div>
   <div class="footer"><center><b>Мой блог для SoftGroup 2017</b></center></div>
   </div>

</body>
</html>