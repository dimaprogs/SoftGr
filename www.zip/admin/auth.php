<?php
  session_start();
  require_once "../lib/functions.php";
  if(checkUser($_SESSION["login"], $_SESSION["password"])){
	  header("Location: /index.php");
	  exit;
  }
?>
<!DOCTYPE html>
<html>
<head>
<title>
   Авторизація
   </title>
<body>

</body>
</html>