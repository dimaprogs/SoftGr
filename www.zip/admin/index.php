<?php
  include("../connect.php");
  require_once "start.php";
  require_once "../lib/functions.php";
?>
<!DOCTYPE html>
<html>
<head>
<title>
   Адміністрування блогу SoftGroup
   </title>
   <link rel="stylesheet" type="text/css" href="../css/style.css">
   <script src="/ckeditor/ckeditor.js"></script>
</head>
<body>
<center>
<h1 id="header">Admin-панель</h1>
<h2>Меню</h2>
<p>
<p><a href="index.php?action=add">Добавити статтю</a></p>
<p><a href="index.php">Список статей</a></p>
</p>
<p><a href="../logout.php">Вихід</a></p>
</center>
<?php
if(isset($_GET['action']))
	$action=$_GET['action'];
else
	$action="";
if($action=="add"){
	if(!empty($_POST)){
		if($_FILES["fupload"]["size"] > 1024*3*1024){
           echo ("Розмір файла більше 3Мб");
           exit;
        }
		articles_new($_POST['title'],$_POST['ch_desc'],$_POST['ckeditor']);
	    if(is_uploaded_file($_FILES["fupload"]["tmp_name"])){
           move_uploaded_file($_FILES["fupload"]["tmp_name"], "/img/full/".$_FILES["fupload"]["name"]);
        } 
		else{
           echo("Помилка загрузки файла");
        }
	}
}
if($action=="add"){
	printf('<div>
	<form method="post" action="index.php?action=add">
	<label>
	<p>Заголовок</p>
	<p><input type="text" name="title" value="" size="60" autofocus required></p>
	</label>
	<label>
	<p>Короткий опис</p>
	<p><textarea name="ch_desc" rows="10" cols="62"></textarea></p>
	</label>
	<label>
	<p>Мініатюра</p>
	<input type="file" name="fupload"/>
	</label>
	<label>
	<p>Текст</p>
	<p><textarea name="ckeditor" width=400></textarea></p>
   <script>
   CKEDITOR.replace( \'ckeditor\' );
   </script>
   </label>
   <p><input type="submit" value="Добавити">
	</form>
	</div>');
}
else if($action=="edit"){
	if(!isset($_GET['id']))
		exit;
	$id=(int)$_GET['id'];
	article_edit($id,$_POST['title'],$_POST['ch_desc'],$_POST['ckeditor']);
}
else if($action=="delete"){
	if(!isset($_GET['id']))
		exit;
	$id=(int)$_GET['id'];
	article_delete($id);
}
else{
	//виводимо список статей
	printf('<table border="1" width="1000">
      <tr>
      <th>Заголовок</th>
      <th>Мініатюра</th>
      <th>Короткий опис</th>
      <th></th>
      <th></th>
      </tr>');
   mysql_query("SET CHARACTER SET 'utf8'");
   $result = mysql_query("select * from data order by id desc limit 0 , 10") or die(mysql_error());
   $data = mysql_fetch_array($result);
   do{
   printf('<tr>
          <td>%s</td>
          <td><img src="%s" width="50"/></td>
          <td>%s</td>
          <td><a href="index.php?action=edit&id=%s">Корегувати</a></td>
		  <td><a href="index.php?action=delete&id=%s">Вилучити</a></td>
		  </tr>',$data["title"],$data["img_url"],$data["m_desc"],$data["id"],$data["id"]);				   
   }
   while($data = mysql_fetch_array($result));
   printf('</table>');
}
?>
</body>
</html>