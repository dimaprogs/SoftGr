<?php
   include("connect.php");
   if(isset($_POST['submit'])){
	   $username=$_POST['username'];
	   $login=$_POST['login'];
	   $password=$_POST['password'];
	   $r_password=$_POST['r_password'];
	   if($password==$r_password){
		   $password=md5($password);
		   $query=mysql_query("insert into users values('','$username','$login','$password',0)") or die(mysql_error());
	   }
	   else{
		  die('Паролі не співпадають!'); 
	   }
	   
   }
?>
<form method="post" action="register.php">
   <input type="text" name="username" placeholder=" | Ім'я" required /><br>
   <input type="text" name="login" placeholder=" | Логін" required /><br>
   <input type="password" name="password" placeholder=" | Пароль" required /><br>
   <input type="password" name="r_password" placeholder=" | Повторіть пароль" required /><br>
   <input type="submit" name="submit" value="Register" />
</form>